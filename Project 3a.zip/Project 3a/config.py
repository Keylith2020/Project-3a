# config.py

API_KEY = "GC43PO0IB14QIJ4E"
