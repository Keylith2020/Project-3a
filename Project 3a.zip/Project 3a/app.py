import os
import requests
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Set the backend to 'Agg' to prevent threading issues
import matplotlib.pyplot as plt
from flask import Flask, render_template, request, redirect, url_for, flash
import io
import base64
from urllib.parse import quote as url_quote

app = Flask(__name__)
app.secret_key = 'supersecretkey'  
app.config['API_KEY'] = 'YOUR_API_KEY_HERE'
app.config["DEBUG"] = True


base_url = "https://www.alphavantage.co/query"

# Load the CSV file with stock symbols
stocks_df = pd.read_csv('stocks.csv')  
stock_symbols = stocks_df['Symbol'].tolist() 

# Route to display the form and the chart
@app.route('/stock_chart' '/', methods=['GET', 'POST'])
def stock_chart():
    chart = None

    if request.method == 'POST':
        # Get form data
        stock_symbol = request.form.get('stock_symbol')
        time_frame = request.form.get('time_frame')
        chart_type = request.form.get('chart_type')
        start_date = request.form.get('start_date')
        end_date = request.form.get('end_date')

        # Validate the dates
        start_date_obj = pd.Timestamp(start_date)
        end_date_obj = pd.Timestamp(end_date)

        if end_date_obj < start_date_obj:
            flash("End date cannot be earlier than start date.", "error")
            return render_template('stock_chart.html', chart=chart, stock_symbols=stock_symbols)

        # Set parameters for the API call
        time_series_function = {
            "daily": "TIME_SERIES_DAILY",
            "weekly": "TIME_SERIES_WEEKLY",
            "monthly": "TIME_SERIES_MONTHLY"
        }.get(time_frame)

        if not time_series_function:
            flash("Invalid time frame selected. Please try again.", "error")
            return render_template('stock_chart.html', chart=chart, stock_symbols=stock_symbols)

        api_key = app.config['API_KEY']
        params = {
            "function": time_series_function,
            "symbol": stock_symbol,
            "apikey": api_key
        }

        # Make the API call
        response = requests.get(base_url, params=params)

        if response.status_code == 200:
            data = response.json()
            time_series_key = {
                "TIME_SERIES_DAILY": "Time Series (Daily)",
                "TIME_SERIES_WEEKLY": "Weekly Time Series",
                "TIME_SERIES_MONTHLY": "Monthly Time Series"
            }.get(time_series_function)

            if time_series_key in data:
                # Convert to pandas DataFrame
                df = pd.DataFrame.from_dict(data[time_series_key], orient='index')
                df.index = pd.to_datetime(df.index)

                # Convert data types explicitly
                df = df.rename(columns={
                    '1. open': 'Open', 
                    '2. high': 'High', 
                    '3. low': 'Low', 
                    '4. close': 'Close', 
                    '5. volume': 'Volume'
                })
                df['Open'] = df['Open'].astype(float)
                df['High'] = df['High'].astype(float)
                df['Low'] = df['Low'].astype(float)
                df['Close'] = df['Close'].astype(float)

                # Filter the DataFrame based on the date range
                df_filtered = df[(df.index >= start_date_obj) & (df.index <= end_date_obj)]

                if df_filtered.empty:
                    flash("No data available for the selected date range.", "warning")
                else:
                    
                    plt.figure(figsize=(10, 5))
                    if chart_type == 'line':
                        plt.plot(df_filtered.index, df_filtered['Close'], marker='o', linestyle='-')
                    elif chart_type == 'bar':
                        plt.bar(df_filtered.index, df_filtered['Close'])
                    
                    plt.title(f'Stock Data for {stock_symbol} - {time_frame.capitalize()}')
                    plt.xlabel('Date')
                    plt.ylabel('Closing Price')
                    plt.grid(True)

                    # Save the plot to a BytesIO object and encode it to base64
                    img = io.BytesIO()
                    plt.savefig(img, format='png')
                    img.seek(0)
                    chart = base64.b64encode(img.getvalue()).decode()
                    plt.close()
            else:
                flash("Data could not be retrieved from the API. Please try again later.", "error")
        else:
            flash("Failed to connect to the stock data API. Please try again later.", "error")

    return render_template('stock_chart.html', chart=chart, stock_symbols=stock_symbols)

@app.route('/')
def home():
    return render_template('base.html')

if __name__ == '__main__':
    app.run()


































